function initMap() {
    const map = new google.maps.Map(document.getElementById("map"), {
      center: { lat: 0, lng: 0 },
      zoom: 2,
    });
  
    const marker = new google.maps.Marker({
      map: map,
      draggable: true,
    });
  
    google.maps.event.addListener(marker, "dragend", function () {
      const position = marker.getPosition();
      const latInput = document.getElementById("lat-input");
      const lonInput = document.getElementById("lon-input");
      latInput.value = position.lat().toFixed(6);
      lonInput.value = position.lng().toFixed(6);
    });
  }
  
  document.getElementById("weather-form").addEventListener("submit", function (event) {
    event.preventDefault();
  
    const lat = document.getElementById("lat-input").value;
    const lon = document.getElementById("lon-input").value;
    const detailingType = document.getElementById("detailing-input").value;
  
    fetch(`/api/weather-forecast/?lat=${lat}&lon=${lon}&detailing_type=${detailingType}`)
      .then((response) => response.json())
      .then((data) => {
        const forecastElement = document.getElementById("forecast");
        forecastElement.innerHTML = JSON.stringify(data, null, 2);
      })
      .catch((error) => {
        console.error(error);
      });
  });
  